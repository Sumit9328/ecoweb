(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_78bab9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_78bab9._.js",
  "chunks": [
    "static/chunks/node_modules_next_c445dd._.js",
    "static/chunks/src_app_656515._.js"
  ],
  "source": "dynamic"
});
